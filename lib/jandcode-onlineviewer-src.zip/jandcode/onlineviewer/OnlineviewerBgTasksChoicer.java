package jandcode.onlineviewer;

import jandcode.bgtasks.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.web.*;

import java.util.*;

/**
 * Выборка задач для onlineviewer
 */
public class OnlineviewerBgTasksChoicer extends BgTasksChoicer {

    protected HashMap<String, Integer> exeLimits = new HashMap<String, Integer>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        //
        Rt x = getApp().getRt().findChild("app/onlineviewer");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                int limit = x1.getValueInt("bgtasks.limit");
                if (limit > 0) {
                    exeLimits.put(x1.getName().toLowerCase(), limit);
                }
            }
        }

    }

    protected String taskToFileId(Task task) {
        String id = null;
        if (task instanceof TaskAction) {
            WebRequest req = ((TaskAction) task).getRequest();
            String pi = req.getPathInfo();
            if (pi.startsWith("onlineviewer/checkdata") || pi.startsWith("onlineviewer/info")) {
                id = req.getParams().getValueString("id");
            }
        }
        return id;
    }

    protected List<String> getUseExe(String fileId, String viewType) throws Exception {
        List<String> res = new ArrayList<String>();
        OnlineviewerService svc = getApp().service(OnlineviewerService.class);
        try {
            FileInfo fi = svc.getFile(fileId);
            FileType ft = svc.getFileType(fi.getType());
            FileConvertor cnv = svc.getFileConvertor(ft.getFileConvertor(viewType));
            res.addAll(cnv.getUseExe());
        } catch (Exception e) {
            //ignore
        }
        return res;
    }

    public boolean checkTaskRun(Task task, Collection<Task> runnedTask) throws Exception {
        // для одного и того же файла нельзя одновременно выполнять 2 задачи
        // некоторые exe имеют ограничения на количество запускаемых экземпляров

        String curId = taskToFileId(task);
        if (!UtString.empty(curId)) {
            // задача имеет отношение к конвертации файлов
            OnlineviewerService svc = getApp().service(OnlineviewerService.class);
            WebRequest req = ((TaskAction) task).getRequest();
            String viewType = req.getParams().getValueString("viewtype");
            //
            HashMap<String, Integer> useExeRunned = new HashMap<String, Integer>();
            for (Task rt : runnedTask) {
                String rid = taskToFileId(rt);
                if (!UtString.empty(rid)) {
                    if (curId.equals(rid)) {
                        // в запущенных задачах имеется задача для этого же файла
                        return false;
                    }
                    if (!UtString.empty(viewType)) {
                        List<String> uex = getUseExe(rid, viewType);
                        for (String ex : uex) {
                            Integer a = useExeRunned.get(ex);
                            if (a == null) {
                                a = 0;
                            }
                            a = a + 1;
                            useExeRunned.put(ex, a);
                        }
                    }
                }
            }

            //
            List<String> uex = getUseExe(curId, viewType);
            for (String ex : uex) {
                Integer a = useExeRunned.get(ex);
                if (a == null) {
                    continue;
                }
                //
                int limit = UtCnv.toInt(exeLimits.get(ex));
                if (limit > 0 && a >= limit) {
                    return false; // превышено число допустимых экземпляров exe
                }
            }

        }

        return true;
    }
}
