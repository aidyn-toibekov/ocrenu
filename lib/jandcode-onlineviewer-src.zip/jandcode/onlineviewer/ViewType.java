package jandcode.onlineviewer;

import jandcode.app.*;

/**
 * Тип просмотра
 */
public class ViewType extends CompRt implements IUnknownRtAttr {

    private String title = "";

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void onUnknownRtAttr(String name, Object value) {
        setProp(name, value);
    }

}
