package jandcode.onlineviewer;

import java.io.*;
import java.util.*;

/**
 * Конвертор для файлов, которые можно представить в виде обычного текста
 */
public abstract class TextFileConvertor extends FileConvertor {

    /**
     * Возвращает ссылку на файл, оторый представляет собой страницу numPage
     */
    public abstract File getFile(FileInfo f) throws Exception;

    //////

    public Map getInfo(FileInfo f) throws Exception {
        Map res = new HashMap();
        return res;
    }

    public File getData(FileInfo f, Map params) throws Exception {
        File res = getFile(f);
        return res;
    }

}
