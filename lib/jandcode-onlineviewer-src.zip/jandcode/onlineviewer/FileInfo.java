package jandcode.onlineviewer;

import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.variant.*;

import java.io.*;

public class FileInfo implements FileProviderFileInfo {

    private String id;
    private String type;
    private String providerName;
    private String providerPath;
    private String cacheDir;
    private IVariantMap props = new VariantMap();
    private String lastModInfo;

    public FileInfo(String baseCacheDir, String providerName, String providerPath) {
        this.providerName = providerName;
        this.providerPath = providerPath;
        this.id = makeId();
        this.cacheDir = UtFile.join(baseCacheDir, makeDir());
    }

    public FileInfo(String baseCacheDir, String id) {
        this.id = id;
        this.cacheDir = UtFile.join(baseCacheDir, makeDir());
    }

    public static String makeId(String providerName, String providerPath) {
        return UtString.md5Str(providerName + "#" + providerPath);
    }

    private String makeId() {
        return makeId(providerName, providerPath);
    }

    private String makeDir() {
        return id.substring(0, 2) + "/" + id.substring(2, 4) + "/" + id;
    }

    //////

    public String getId() {
        return id;
    }

    /**
     * Тип файла (pdf, png ...). Обычно - расширение файла
     */
    public String getType() {
        return type;
    }

    public void setType(String fileType) {
        this.type = fileType;
    }

    /**
     * Имя провайдера
     *
     * @return
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * Путь файла в провайдере
     *
     * @return
     */
    public String getProviderPath() {
        return providerPath;
    }

    /**
     * Различные свойства для использования конверторами
     */
    public IVariantMap getProps() {
        return props;
    }

    //////

    /**
     * Каталог с кешем этого файла
     */
    public String getCacheDir() {
        return cacheDir;
    }

    /**
     * Имя ok-файла
     */
    public String getFile(String localFileName) {
        return UtFile.join(getCacheDir(), localFileName);
    }

    /**
     * Имя ok-файла
     */
    public String getFileOk() {
        return getFile(OnlineviewerService.FILE_OK);
    }

    /**
     * Имя data-файла
     */
    public String getFileData() {
        return getFile(OnlineviewerService.FILE_DATA);
    }

    /**
     * Имя info-файла
     */
    public String getFileInfo() {
        return getFile(OnlineviewerService.FILE_INFO);
    }

    //////

    private void saveToXml(EasyXml x) {
        x.getAttrs().put("type", getType());
        x.getAttrs().put("providerName", getProviderName());
        x.getAttrs().put("providerPath", getProviderPath());
        if (isNeedCheckModified()) {
            x.getAttrs().put("lastModInfo", getLastModInfo());
        }
        EasyXml xp = x.addChild("props");
        xp.getAttrs().putAll(props);
    }

    private void loadFromXml(EasyXml x) {
        type = x.getAttrs().getValueString("type");
        providerName = x.getAttrs().getValueString("providerName");
        providerPath = x.getAttrs().getValueString("providerPath");
        lastModInfo = x.getAttrs().getValueString("lastModInfo");
        props.clear();
        EasyXml xp = x.findChild("props");
        if (xp != null) {
            props.putAll(xp.getAttrs());
        }
    }

    /**
     * Прочитать файл info
     */
    public void load() throws Exception {
        EasyXml x = new EasyXml();
        x.load().fromFile(getFileInfo());
        loadFromXml(x);
    }

    /**
     * Записать файл info
     */
    public void save() throws Exception {
        // удаляем флаг
        File f = new File(getFileOk());
        f.delete();
        // записываем info
        EasyXml x = new EasyXml();
        saveToXml(x);
        x.save().toFile(getFileInfo());
        // ставим флаг
        UtFile.saveString("ok", f);
    }

    public String getLastModInfo() {
        return lastModInfo;
    }

    public void setLastModInfo(String lastModInfo) {
        this.lastModInfo = lastModInfo;
    }

    /**
     * Нужно ли проверять файл на предмет его более свежей версии.
     */
    public boolean isNeedCheckModified() {
        return !UtString.empty(lastModInfo);
    }

}
