/**
 * Компонент для просмотра постраничных картинок
 */
Ext.define('Jc.onlineviewer.Viewer_image', {
    extend: 'Ext.Component',

    baseCls: 'jc-onlineviewer-image',

    renderTpl: [
        '<div class="{baseCls}-wrap">',
        '  <img class="{baseCls}-content" style="display: none;">',
        '</div>'
    ],

    isFocusable: false,

    // это результат onlineviewer/info
    viewInfo: null,

    // текущая страница
    imageCurPage: 0,

    // угол поворота
    imageRotate: 0,

    // оригинальные размеры картинки
    imageWidth: 0,
    imageHeight: 0,

    imageFirstRender: true,

    initComponent: function() {
        var th = this;
        Ext.applyIf(th.renderSelectors, {
            imageEl: '.' + th.baseCls + '-content'
        });
        this.addEvents("contentchange");
        this.callParent(arguments);
        //
        th.on('afterrender', function() {
            th.imageEl.on('load', function() {
                th.fireEvent("contentchange", th);
                var dom = th.imageEl.dom;
                th.imageWidth = dom.naturalWidth;
                th.imageHeight = dom.naturalHeight;
                th.getEl().setScrollLeft(0);
                th.getEl().setScrollTop(0);
                if (th.imageFirstRender) {
                    th.imageFirstRender = false;
                    th.scaleActual();
                }
                th.imageEl.setVisible(true);
            });
            th.loadPage(0);
        });
    },

    loadPage: function(num) {
        var th = this;
        if (Ext.isString(num)) {
            num = Jc.toInt(num);
        }
        if (!num) num = 1;
        //
        th.imageCurPage = num;
        th.imageEl.setVisible(false);
        //
        Ext.Ajax.requestBg({
            url: Jc.url('onlineviewer/checkdata'),
            params: {id: th.viewInfo.id, viewtype: th.viewInfo.viewtype, page: th.imageCurPage, rotate: th.imageRotate},
            success: function(response, opts) {
                var s = response.responseText;
                var jsonData;
                try {
                    jsonData = Ext.decode(s);
                } catch(e) {
                    Jc.error(e);
                }
                if (jsonData.success === false || jsonData.success === "false") {
                    Jc.error(new Jc.Error({err: jsonData, type: 'json'}));
                }
                // все ок
                th.imageEl.dom.src = Jc.format(Jc.url(
                    'onlineviewer/data?id={0}&viewtype={1}&page={2}&rotate={3}'),
                  th.viewInfo.id, th.viewInfo.viewtype, th.imageCurPage, th.imageRotate);
                //
            },
            failure: function(response, opts) {
                Jc.error(response, false);
            }
        });

    },

    nextPage: function() {
        if (this.imageCurPage >= this.viewInfo.pages) {
            return;
        }
        this.loadPage(this.imageCurPage + 1);
    },

    prevPage: function() {
        if (this.imageCurPage <= 1) {
            return;
        }
        this.loadPage(this.imageCurPage - 1);
    },

    firstPage: function() {
        this.loadPage(1);
    },

    lastPage: function() {
        this.loadPage(this.viewInfo.pages);
    },

    //////

    getMetrics: function() {
        var m = {};
        m.wF = this.getEl().getWidth() - 50;
        m.hF = this.getEl().getHeight() - 50;
        m.wI = this.imageWidth;
        m.hI = this.imageHeight;
        return m;
    },

    /**
     * Увеличить масштаб
     */
    zoomIn: function() {
        this.imageEl.setHeight(this.imageEl.getHeight() + 200);
    },

    /**
     * Уменьшить масштаб
     */
    zoomOut: function() {
        if (this.imageEl.getHeight() > 400) {
            this.imageEl.setHeight(this.imageEl.getHeight() - 200);
        }
    },

    /**
     * Масштаб 1:1
     */
    scaleOriginal: function() {
        var m = this.getMetrics();
        this.imageEl.setHeight(m.hI);
    },

    /**
     * Масштаб актуальный: если картинка больше окна, масштабируется по окну, иначе -
     * оригинальный размер.
     */
    scaleActual: function() {
        var m = this.getMetrics();
        if (m.wI > m.wF) {
            this.fitWidth();
        } else {
            this.scaleOriginal();
        }
    },

    /**
     * Масштаб: по ширине окна
     */
    fitWidth: function() {
        var m = this.getMetrics();
        var sc = m.wF / m.wI;
        var h = sc * m.hI;
        this.imageEl.setHeight(h);
    },

    /**
     * Масштаб: разместить страницу
     */
    fitPage: function() {
        var m = this.getMetrics();
        if (m.wI <= m.wF && m.hI <= m.hF) {
            this.scaleOriginal();
        } else if (m.wI > m.wF && m.hI <= m.hF) {
            this.fitWidth();
        } else if (m.wI <= m.wF && m.hI > m.hF) {
            this.imageEl.setHeight(m.hF);
        } else {
            var sw = m.wI / m.wF;
            var sh = m.hI / m.hF;
            if (sh > sw) {
                this.imageEl.setHeight(m.hF);
            } else {
                this.fitWidth();
            }
        }

    },

    rotateLeft: function() {
        this.imageRotate = this.imageRotate - 90;
        if (this.imageRotate < 0) {
            this.imageRotate = 270;
        }
        this.loadPage(this.imageCurPage);
    },

    rotateRight: function() {
        this.imageRotate = this.imageRotate + 90;
        if (this.imageRotate >= 360) {
            this.imageRotate = 0;
        }
        this.loadPage(this.imageCurPage);
    },

    /**
     * Возвращает элементы toolbar для использования в контейнерах (например во фрейме).
     */
    createToolbarItems: function() {
        var th = this;
        var tb_inpPageNum;
        var b = Jc.app.createBuilder({frame: th});
        //
        th.on('contentchange', function() {
            tb_inpPageNum.setValue('' + th.imageCurPage + ' / ' + th.viewInfo.pages);
        });
        //
        tb_inpPageNum = b.input(null, {width: 80, selectOnFocus: true, enableKeyEvents: true});
        tb_inpPageNum.on("keydown", function(t, e) {
            if (e.getKey() == e.ENTER) {
                th.loadPage(t.getValue());
                th.focus();
            }
        });

        return [
            b.action({
                icon: 'ov-zoom-in', tooltip: UtLang.t('Уменьшить'), onExec: function() {
                    th.zoomIn();
                }
            }),
            b.action({
                icon: 'ov-zoom-out', tooltip: UtLang.t('Увеличить'), onExec: function() {
                    th.zoomOut();
                }
            }),
            b.action({
                icon: 'ov-scale-original', tooltip: UtLang.t('Оригинальный размер'), onExec: function() {
                    th.scaleOriginal();
                }
            }),
            b.action({
                icon: 'ov-fit-width', tooltip: UtLang.t('По ширине страницы'), onExec: function() {
                    th.fitWidth();
                }
            }),
            b.action({
                icon: 'ov-fit-page', tooltip: UtLang.t('Разместить страницу'), onExec: function() {
                    th.fitPage();
                }
            }),
            b.action({
                icon: 'ov-scale-actual', tooltip: UtLang.t('Актуальный размер'), onExec: function() {
                    th.scaleActual();
                }
            }),
            b.action({
                icon: 'ov-rotate-right', tooltip: UtLang.t('Повернуть по часовой стрелке'), onExec: function() {
                    th.rotateRight();
                }
            }),
            b.action({
                icon: 'ov-rotate-left', tooltip: UtLang.t('Повернуть против часовой стрелке'), onExec: function() {
                    th.rotateLeft();
                }
            }),
            '-',
            b.action({
                icon: 'ov-page-first', tooltip: UtLang.t('Первая страница'), onExec: function() {
                    th.firstPage();
                }
            }),
            b.action({
                icon: 'ov-page-prev', tooltip: UtLang.t('Предыдущая страница'), onExec: function() {
                    th.prevPage();
                }
            }),

            tb_inpPageNum,

            b.action({
                icon: 'ov-page-next', tooltip: UtLang.t('Следующая страница'), onExec: function() {
                    th.nextPage();
                }
            }),
            b.action({
                icon: 'ov-page-last', tooltip: UtLang.t('Последняя страница'), onExec: function() {
                    th.lastPage();
                }
            })
        ];
    }


});
 