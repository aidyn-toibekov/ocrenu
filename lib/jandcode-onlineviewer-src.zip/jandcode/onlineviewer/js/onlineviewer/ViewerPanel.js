/**
 * Контейнер для конкретных просмотрщиков
 */
Ext.define('Jc.onlineviewer.ViewerPanel', {
    extend: 'Ext.Panel',

    requires: ['Jc.bgtasks.BgManager'],

    cls: 'jc-onlineviewer-panel',

    isFocusable: false,

    // id загруженного файла
    fileId: null,

    // тип загруженного файла (расширение)
    fileType: null,

    // список поддерживаемых типов просмотра
    fileViewTypes: null,

    // текущий viewtype
    fileViewType: null,

    // текущий viewer
    viewer: null,

    // показывать ли личную toolbar
    showToolbar: true,

    // показывать свою toolbar после toolbar для viewer, иначе - перед ней
    afterViewerToolbar: true,

    initComponent: function() {
        var th = this;
        th.layout = 'fit';
        th.cls = "jc-onlineviewer-panel";
        if (th.showToolbar) {
            th.toolbar = Ext.create('Ext.toolbar.Toolbar', {dock: 'top', hidden: true});
            th.dockedItems = [th.toolbar];
        }
        //
        this.callParent(arguments);
    },

    /**
     * Загрузить в компонент новый файл.
     * @param provider какой провайдер
     * @param path путь файла для провайдера
     */
    loadFile: function(provider, path) {
        var th = this;
        //
        th.fileId = null;
        th.fileType = null;
        th.fileViewTypes = null;
        //
        Ext.Ajax.requestBg({
            url: Jc.url('onlineviewer/resolve'),
            params: {provider: provider, path: path},
            success: function(response, opts) {
                var s = response.responseText;
                var jsonData;
                try {
                    jsonData = Ext.decode(s);
                } catch(e) {
                    Jc.error(e);
                }
                if (jsonData.success === false || jsonData.success === "false") {
                    Jc.error(new Jc.Error({err: jsonData, type: 'json'}));
                }
                //
                th.fileId = jsonData.id;
                th.fileType = jsonData.type;
                th.fileViewTypes = jsonData.viewtypes;
                //
                th.changeViewType(0);
                //
            },
            failure: function(response, opts) {
                Jc.error(response, false);
            }
        });
    },

    getViewType: function(vt) {
        return this.fileViewTypes[vt];
    },

    changeViewType: function(vt) {
        var th = this;
        th.removeAll();
        th.viewer = null;
        th.fileViewType = th.getViewType(vt);

        // делаем запрос на info
        Ext.Ajax.requestBg({
            url: Jc.url('onlineviewer/info'),
            params: {id: th.fileId, viewtype: th.fileViewType.name},
            success: function(response, opts) {
                var s = response.responseText;
                var jsonData;
                try {
                    jsonData = Ext.decode(s);
                } catch(e) {
                    Jc.error(e);
                }
                if (jsonData.success === false || jsonData.success === "false") {
                    Jc.error(new Jc.Error({err: jsonData, type: 'json'}));
                }
                //
                th.viewer = Ext.create(th.fileViewType.jsclass, {viewInfo: jsonData});
                th.recreateToolbar();
                //
                th.add(th.viewer);
                //
            },
            failure: function(response, opts) {
                Jc.error(response, false);
            }
        });
    },

    recreateToolbar: function() {
        var th = this;
        if (!th.toolbar) {
            return;
        }
        if (!th.viewer) {
            th.toolbar.setVisible(false);
            return;
        }
        //
        th.toolbar.removeAll();

        var tb1 = th.createToolbarItems();
        var tb2;
        if (th.viewer.createToolbarItems) {
            tb2 = th.viewer.createToolbarItems();
        }

        if (th.afterViewerToolbar) {
            var tmp = tb2;
            tb2 = tb1;
            tb2 = tmp;
        }

        if (tb1) {
            th.toolbar.add(tb1);
            if (tb2) {
                th.toolbar.add("-");
            }
        }
        if (tb2) {
            th.toolbar.add(tb2);
        }
        //
        if (th.toolbar.items.getCount() > 0) {
            th.toolbar.setVisible(true);
        } else {
            th.toolbar.setVisible(false);
        }
    },

    createToolbarItems: function() {
        var th = this;
        if (!th.toolbar) {
            return;
        }
        if (!th.viewer) {
            return;
        }
        //
        return [
            Jc.action({icon: "download", tooltip: UtLang.t('Скачать'), onExec: function() {
                Jc.requestDownload({
                    url: 'onlineviewer/download',
                    params: {id: th.fileId, viewtype: th.fileViewType.name}
                })
            }})
        ]
    }


});

