/**
 * Компонент для просмотра обычного текста
 */
Ext.define('Jc.onlineviewer.Viewer_text', {
    extend: 'Ext.Component',

    // это результат onlineviewer/info
    viewInfo: null,

    initComponent: function() {
        var th = this;
        //
        th.cls = "jc-onlineviewer-text";
        th.autoScroll = true;
        //
        th.callParent(arguments);
        //
        th.on("afterrender", function() {
            th.updateFileData();
        });
    },

    updateFileData: function() {
        var th = this;
        Ext.Ajax.request({
            url: Jc.url('onlineviewer/data'),
            params: {id: th.viewInfo.id, viewtype: th.viewInfo.viewtype},
            success: function(response, opts) {
                var s = response.responseText;
                s = "<div class='jc-onlineviewer-text-content'>" + Ext.String.htmlEncode(s) + "</div>";
                th.update(s);
            },
            failure: function(response, opts) {
                Jc.error(response, false);
            }
        });

    }

});
 