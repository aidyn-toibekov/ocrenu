package jandcode.onlineviewer;

import jandcode.app.*;
import jandcode.utils.rt.*;

import java.io.*;
import java.util.*;

/**
 * Конвертор файлов.
 * Преобразует закэшированный файл в формат, пригодный к показу на клиенте.
 */
public abstract class FileConvertor extends CompRt {

    protected List<String> useExe = new ArrayList<String>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        //
        Rt x = rt.findChild("useexe");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                useExe.add(x1.getName().toLowerCase());
            }
        }

    }

    /**
     * Список имен exe, которые использует данный конвертор.
     * Для bgtasks: контроль одновременного выполнения ограниченного числа exe
     * определенного вида.
     */
    public List<String> getUseExe() {
        return useExe;
    }

    /**
     * Возвращает информацию о файле для отображения на клиенте.
     * Зависит от конкретного типа просмотрщика. Например для image возвращается
     * количество страниц.
     */
    public abstract Map getInfo(FileInfo f) throws Exception;

    /**
     * Возвращает ссылку на файл, который нужно отдать клиенту в ответ на запрос
     * params. Формат запроса зависит от типа просмотрщика.
     */
    public abstract File getData(FileInfo f, Map params) throws Exception;


}
