package jandcode.onlineviewer;

/**
 * Интерфейс для передачи информации о файле от провайдера
 */
public interface FileProviderFileInfo {

    /**
     * Тип файла (pdf, png ...). Обычно - расширение файла.
     */
    void setType(String type);

    /**
     * Установить информацию о кеше. Эта информация должна содержать в себе то, что
     * позволит провайдеру принять решение - менялся ли файл с момента последнего
     * к нему обращения.
     */
    void setLastModInfo(String lastModInfo);

}
