package jandcode.onlineviewer;

import jandcode.app.*;

/**
 * Сервис поддержки onlineviewer
 */
public abstract class OnlineviewerService extends CompRt {

    public static final String DATADIR = "onlineviewer.cache";
    public static final String FILE_OK = "ok.flag";
    public static final String FILE_DATA = "file.data";
    public static final String FILE_INFO = "info.xml";

    /**
     * Получить информацию о файле
     *
     * @param providerName от какого провайдера
     * @param path         что за файл
     * @see FileProvider#resolveFile(java.lang.String, java.io.File, jandcode.onlineviewer.FileProviderFileInfo)
     */
    public abstract FileInfo resolveFile(String providerName, String path) throws Exception;

    /**
     * Найти информацию о файле
     *
     * @param id что за файл
     */
    public abstract FileInfo getFile(String id) throws Exception;

    /**
     * Тип файла по имени типа
     *
     * @param name имя типа (обычно расширение)
     */
    public abstract FileType getFileType(String name) throws Exception;


    /**
     * FileConvertor по имени. Имя обычно берется из FileType
     */
    public abstract FileConvertor getFileConvertor(String name) throws Exception;

    /**
     * ViewType по имени
     */
    public abstract ViewType getViewType(String name) throws Exception;


}
