package jandcode.onlineviewer;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Тип файла.
 * Имя типа - расширение файла.
 */
public class FileType extends CompRt {

    private Map<String, String> viewTypeInfos = new LinkedHashMap<String, String>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt x = rt.findChild("viewtype");
        if (x != null) {
            for (Rt z : x.getChilds()) {
                String key = z.getName();
                String v = z.getValueString("fileconvertor");
                if (UtString.empty(v)) {
                    throw new XError("Не указан fileconvertor для типа файла {0}", key);
                }
                viewTypeInfos.put(key, v);
            }
        }
    }

    /**
     * Список поддерживаемых viewtype
     */
    public Collection<String> getViewTypes() {
        return viewTypeInfos.keySet();
    }

    public String getFileConvertor(String viewtype) {
        String fc = viewTypeInfos.get(viewtype);
        if (UtString.empty(viewtype)) {
            throw new XError("Тип файла {0} не поддерживает viewtype {1}", getName(), viewtype);
        }
        return fc;
    }

}
