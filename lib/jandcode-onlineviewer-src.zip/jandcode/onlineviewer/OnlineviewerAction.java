package jandcode.onlineviewer;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;

import java.io.*;
import java.util.*;

/**
 * Внешний интерфейс для jandcode.onlineviewer.OnlineviewerService
 */
public class OnlineviewerAction extends WebAction {

    public static final String P_PROVIDER = "provider";
    public static final String P_PATH = "path";
    public static final String P_ID = "id";
    public static final String P_VIEWTYPE = "viewtype";

    public class RequestInfo {

        String providerName;
        String path;
        String id;
        String viewTypeName;
        OnlineviewerService svc;
        FileInfo fileInfo;
        FileType fileType;
        ViewType viewType;
        FileConvertor cnv;

        public RequestInfo(boolean resolve) throws Exception {
            svc = getApp().service(OnlineviewerService.class);
            if (resolve) {
                providerName = getParam(P_PROVIDER);
                path = getParam(P_PATH);
                fileInfo = svc.resolveFile(providerName, path);
                fileType = svc.getFileType(fileInfo.getType());
            } else {
                id = getParam(P_ID);
                viewTypeName = getParam(P_VIEWTYPE);
                fileInfo = svc.getFile(id);
                viewType = svc.getViewType(viewTypeName);
                fileType = svc.getFileType(fileInfo.getType());
                cnv = svc.getFileConvertor(fileType.getFileConvertor(viewTypeName));
            }
        }

        String getParam(String name) {
            String res = getParams().getValueString(name).trim();
            if (UtString.empty(res)) {
                throw new XError("param required [{0}]", name);
            }
            return res;
        }

        File getData() throws Exception {
            return cnv.getData(fileInfo, getRequest().getParams());
        }

        Map getInfo() throws Exception {
            return cnv.getInfo(fileInfo);
        }

    }


    /**
     * для provider и path возвращает информацию о файле:
     * id - id файла
     * type - тип (расширение)
     * viewtypes - массив поддерживаемых viewtype для файла
     */
    public void resolve(JsonActionWrapper wrap) throws Exception {
        RequestInfo req = new RequestInfo(true);

        //
        List<Map> viewtypes = new ArrayList<Map>();
        for (String n : req.fileType.getViewTypes()) {
            ViewType vt = req.svc.getViewType(n);
            Map m = new LinkedHashMap();
            m.put("name", vt.getName());
            m.put("title", vt.getTitle());
            m.putAll(vt.getProps());
            viewtypes.add(m);
        }

        if (viewtypes.size() == 0) {
            throw new XError("Ну указаны viewtypes для файла типа {0}", req.fileType.getName());
        }

        // результат
        Map res = new HashMap();
        res.put("id", req.fileInfo.getId());
        res.put("type", req.fileInfo.getType());
        res.put("viewtypes", viewtypes);

        wrap.setJson(res);
    }

    /**
     * Получение информации о файле для настройки отображения.
     * параметры:
     * id - id файла
     * viewtype - тип просмотра
     * <p/>
     * Возвращает то, что возвращает {@link FileConvertor#getInfo(jandcode.onlineviewer.FileInfo)}
     */
    public void info(JsonActionWrapper wrap) throws Exception {
        RequestInfo req = new RequestInfo(false);
        //
        Map res = new LinkedHashMap();
        res.put("id", req.fileInfo.getId());
        res.put("viewtype", req.viewType.getName());
        res.putAll(req.getInfo());
        //
        wrap.setJson(res);
    }

    /**
     * Получение данных для файла
     * параметры:
     * id - id файла
     * viewtype - тип просмотра
     * остальные параметры определяются {@link FileConvertor#getData(jandcode.onlineviewer.FileInfo, java.util.Map)}
     * <p/>
     * Возвращает файл {@link FileConvertor#getData(jandcode.onlineviewer.FileInfo, java.util.Map)}
     */
    public void data() throws Exception {
        RequestInfo req = new RequestInfo(false);
        //
        File f = req.getData();
        //
        InputStream srcSt = new FileInputStream(f);
        OutputStream destSt = getRequest().getOutStream();
        try {
            UtFile.copyStream(srcSt, destSt);
        } finally {
            srcSt.close();
        }
    }

    /**
     * Проверка наличия данных для файла. Параметры - как в методе data
     */
    public void checkdata(JsonActionWrapper wrap) throws Exception {
        RequestInfo req = new RequestInfo(false);
        //
        File f = req.getData();
        //
        Map res = new LinkedHashMap();
        res.put("id", req.fileInfo.getId());
        res.put("viewtype", req.viewType.getName());
        //
        wrap.setJson(res);
    }

    /**
     * Загрузка файла
     */
    public void download() throws Exception {
        RequestInfo req = new RequestInfo(false);
        //
        File f = new File(req.fileInfo.getFileData());
        //
        getRequest().setHeaderDownload("download-" + req.fileInfo.getId() + "." + req.fileType.getName());
        //
        InputStream srcSt = new FileInputStream(f);
        OutputStream destSt = getRequest().getOutStream();
        try {
            UtFile.copyStream(srcSt, destSt);
        } finally {
            srcSt.close();
        }
    }

}
