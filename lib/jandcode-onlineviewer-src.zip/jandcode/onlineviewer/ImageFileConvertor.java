package jandcode.onlineviewer;

import jandcode.onlineviewer.impl.exe.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.io.*;
import java.util.*;

/**
 * Конвертор для файлов, которые можно представить в виде набора
 * картинок страниц в формате jpg или png.
 */
public abstract class ImageFileConvertor extends FileConvertor {

    /**
     * Число страниц в этом файле
     */
    public abstract int getCountPages(FileInfo f) throws Exception;

    /**
     * Возвращает ссылку на файл, оторый представляет собой страницу numPage
     */
    public abstract File getPageFile(FileInfo f, int numPage) throws Exception;

    /**
     * Возвращает ссылку на файл, оторый представляет собой страницу numPage
     * повернутую на degrees градусов
     */
    public File getPageFileRotate(FileInfo f, int numPage, int degrees) throws Exception {
        File res = getPageFile(f, numPage);

        if (degrees > 0 && degrees < 360) {
            // нужен поворот
            String s = res.getAbsolutePath();
            File resRotated = new File(UtFile.path(s) + "/" + UtFile.basename(s) + "-" + degrees + "." + UtFile.ext(s));
            if (!resRotated.exists()) {
                // не существует, создаем
                ImagemagikExe cnv = new ImagemagikExe(getApp());
                cnv.rotate(res.getAbsolutePath(), resRotated.getAbsolutePath(), degrees);
            }
            res = resRotated;
        }
        return res;
    }

    public Map getInfo(FileInfo f) throws Exception {
        Map res = new HashMap();
        int pages = getCountPages(f);
        res.put("pages", pages);
        return res;
    }

    public File getData(FileInfo f, Map params) throws Exception {
        VariantMapWrap m = new VariantMapWrap(params);
        int page = m.getValueInt("page", 1);
        int rotate = m.getValueInt("rotate", 0);
        File res = getPageFileRotate(f, page, rotate);
        return res;
    }

}
