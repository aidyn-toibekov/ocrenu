package jandcode.onlineviewer;

import jandcode.app.*;

import java.io.*;

/**
 * Провайдер файлов.
 * Его задача: по переданному path найти где-то файл (где угодно) и воссоздать
 * этот файл в месте, в котором ему укажут.
 */
public abstract class FileProvider extends CompRt {

    /**
     * По строке path находит файл и копирует его во временное место destFile
     * Если задача не выполнена, сгенерировать Еxception.
     *
     * @param path         что за файл. Формат зависит от провайдера
     * @param destFile     куда скопировать найденный файл (это временный файл)
     * @param destFileInfo описание найденного файла.
     *                     Нужно обязательно выполнить {@link FileProviderFileInfo#setType(java.lang.String)}.
     *                     Дополнительно можно присвоить {@link FileProviderFileInfo#setLastModInfo(java.lang.String)},
     *                     тогда перед показаом файла будет запущена проверка на измененный файл
     *                     {@link FileProvider#checkModifiedFile(java.lang.String, java.lang.String)}.
     */
    public abstract void resolveFile(String path, File destFile, FileProviderFileInfo destFileInfo) throws Exception;

    /**
     * Проверить что файл менялся с момента lastModInfo.
     *
     * @param path        что за файл. Формат зависит от провайдера
     * @param lastModInfo то, что было присвоено в setLastModInfo() в методе resolveFile
     * @return true, если файл изменился и его нужно закешировать заново
     */
    public abstract boolean checkModifiedFile(String path, String lastModInfo) throws Exception;

}

