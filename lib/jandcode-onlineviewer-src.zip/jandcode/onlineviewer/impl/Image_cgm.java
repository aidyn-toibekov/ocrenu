package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;
import org.apache.commons.io.*;

import java.io.*;

/**
 * Конвертация cgm в png
 */
public class Image_cgm extends ImageFileConvertor {

    public int getCountPages(FileInfo f) throws Exception {
        return 1;
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        File f_cgm = new File(f.getFile("file.cgm"));
        if (!f_cgm.exists()) {
            FileUtils.copyFile(new File(f.getFileData()), f_cgm);
        }
        File pf = new File(f.getFile("file.png"));
        if (!pf.exists()) {
            NConvertExe cnv = new NConvertExe(getApp());
            cnv.convertCgm(f_cgm.getAbsolutePath(), pf.getAbsolutePath());
        }
        return pf;
    }

}
