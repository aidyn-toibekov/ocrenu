package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;

import java.io.*;

/**
 * Конвертация различных картинок в jpg/png
 */
public class Image_cdr extends ImageFileConvertor {

    public int getCountPages(FileInfo f) throws Exception {
        return 1;
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        File pf = new File(f.getFile("file.jpg"));
        if (!pf.exists()) {
            String svg = f.getFile("file.svg");
            UniConvertorExe unicnv = new UniConvertorExe(getApp());
            unicnv.convert(f.getFileData(), svg, "");
            //
            ImagemagikExe cnv = new ImagemagikExe(getApp());
            cnv.convert(svg, pf.getAbsolutePath(), "", true);
        }
        return pf;
    }

}
