package jandcode.onlineviewer.impl;

import jandcode.app.*;
import jandcode.onlineviewer.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;

import java.io.*;

public class OnlineviewerServiceImpl extends OnlineviewerService {

    protected static Log log = LogFactory.getLog(OnlineviewerService.class);

    ListNamed<FileProvider> fileProviders = new ListNamed<FileProvider>();
    ListNamed<FileConvertor> fileConvertors = new ListNamed<FileConvertor>();
    ListNamed<FileType> fileTypes = new ListNamed<FileType>();
    ListNamed<ViewType> viewTypes = new ListNamed<ViewType>();


    public OnlineviewerServiceImpl() {
        fileProviders.setNotFoundMessage("FileProvider {0} not found");
        fileConvertors.setNotFoundMessage("FileConvertor {0} not found");
        fileTypes.setNotFoundMessage("Тип файла [{0}] не поддерживается");
        viewTypes.setNotFoundMessage("View type [{0}] not found");
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        //
        Rt x = rt.findChild("fileprovider");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                FileProvider p = (FileProvider) getApp().getObjectFactory().create(x1);
                fileProviders.add(p);
            }
        }

        //
        x = rt.findChild("fileconvertor");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                FileConvertor p = (FileConvertor) getApp().getObjectFactory().create(x1);
                fileConvertors.add(p);
            }
        }

        //
        x = rt.findChild("filetype");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                FileType p = (FileType) getApp().getObjectFactory().create(x1, FileType.class);
                fileTypes.add(p);
            }
        }

        //
        x = rt.findChild("viewtype");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                ViewType p = (ViewType) getApp().getObjectFactory().create(x1, ViewType.class);
                viewTypes.add(p);
            }
        }

        //
    }

    public FileInfo resolveFile(String providerName, String path) throws Exception {
        FileProvider p = fileProviders.get(providerName);

        // ищем такой файл в кеше
        String baseCacheDir = getApp().service(DataDirService.class).getDataDir(DATADIR);
        FileInfo info = new FileInfo(baseCacheDir, providerName, path);
        boolean cacheExists = false;

        if (UtFile.exists(info.getFileOk()) && UtFile.exists(info.getFileData())) {
            // кеш готов к использованию
            try {
                info.load();

                if (info.isNeedCheckModified()) {
                    if (!p.checkModifiedFile(path, info.getLastModInfo())) {
                        cacheExists = true;
                    }
                } else {
                    cacheExists = true;
                }

            } catch (Exception ignore) {
            }
        }

        if (!cacheExists) {
            // файла такого нет, кешируем и обрабатываем
            UtFile.cleanDir(info.getCacheDir());

            // получаем файл от провайдера
            File f = new File(info.getFileData());
            log.info("resolve file: " + providerName + ":" + path);
            p.resolveFile(path, f, info);
            if (UtString.empty(info.getType())) {
                throw new XError("Not assigned file type for: {0}:{1}. Check provider.", providerName, path);
            }

            // файл получен

            // сохраняем info
            info.save();

            // перечитываем для исключения коллизий
            info.load();
        }

        return info;
    }

    public FileInfo getFile(String id) throws Exception {
        // ищем такой файл в кеше
        String baseCacheDir = getApp().service(DataDirService.class).getDataDir(DATADIR);
        FileInfo info = new FileInfo(baseCacheDir, id);

        if (UtFile.exists(info.getFileOk())) {
            // кеш готов к использованию
            info.load();
            return info;
        } else {
            throw new XError("Файл не найден: {0}", id);
        }
    }

    public FileType getFileType(String name) throws Exception {
        return fileTypes.get(name);
    }

    public FileConvertor getFileConvertor(String name) throws Exception {
        return fileConvertors.get(name);
    }

    public ViewType getViewType(String name) throws Exception {
        return viewTypes.get(name);
    }

}
