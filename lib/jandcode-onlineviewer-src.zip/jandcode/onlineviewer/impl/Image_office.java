package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.io.*;
import java.util.*;

/**
 * office: doc ... и т.д.
 */
public class Image_office extends ImageFileConvertor {

    public static final String FILE_PDF = "file.pdf";

    protected String getOfsExe() {
        String p = "app/onlineviewer/libreoffice:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found libreoffice config: {0}", p);
        }
        return exe;
    }

    protected void checkPdf(FileInfo f) throws Exception {
        File pdfFile = new File(f.getFile(FILE_PDF));
        if (!pdfFile.exists()) {
            // pdf не существует - создаем
            RunExe r = new RunExe(getApp().isDebug());
            List<String> cmd = new ArrayList<String>();
            // ofs --headless --convert-to pdf file.data
            cmd.add(getOfsExe());
            cmd.add("--headless");
            cmd.add("--convert-to");
            cmd.add("pdf");
            cmd.add(UtFile.filename(f.getFileData()));
            r.runexe(cmd, f.getCacheDir(), false, true);
        }
    }

    public int getCountPages(FileInfo f) throws Exception {
        checkPdf(f);
        PdfExe cnv = new PdfExe(getApp(), f, FILE_PDF);
        return cnv.getCountPages();
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        checkPdf(f);
        PdfExe cnv = new PdfExe(getApp(), f, FILE_PDF);
        return cnv.getPageFile(numPage);
    }

}
