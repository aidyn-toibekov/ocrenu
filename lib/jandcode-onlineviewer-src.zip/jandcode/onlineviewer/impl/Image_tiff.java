package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;
import jandcode.utils.error.*;

import java.io.*;

/**
 * Конвертация tiff, включая многостраничные
 */
public class Image_tiff extends ImageFileConvertor {

    public int getCountPages(FileInfo f) throws Exception {
        int cp = f.getProps().getValueInt("countPages", -1);
        if (cp < 0) {
            // еще не считали
            ImagemagikIdentifyExe z = new ImagemagikIdentifyExe(getApp());
            cp = z.tiffPages(f.getFileData());
            if (cp == 0) {
                cp = 1;
            }
            f.getProps().setValue("countPages", cp);
            f.save();
        }
        return cp;
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        int cp = getCountPages(f);
        if (numPage <= 0 || numPage > cp) {
            throw new XError("Invalid pagenum");
        }
        File pf = new File(f.getFile("page-" + numPage + ".png"));
        if (!pf.exists()) {
            // делаем все страницы сразу...
            ImagemagikExe e = new ImagemagikExe(getApp());
            e.convert(f.getFileData(), f.getFile("page-%d.png"), "-scene 1", false);

            if (!pf.exists()) {
                throw new XError("Error convert tiff: {0}", f.getFileData());
            }

        }
        return pf;
    }

}
