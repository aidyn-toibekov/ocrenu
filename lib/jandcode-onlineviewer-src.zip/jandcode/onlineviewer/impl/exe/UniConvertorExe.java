package jandcode.onlineviewer.impl.exe;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Конвертация с использованием uniconvertor
 */
public class UniConvertorExe {

    private App app;

    public UniConvertorExe(App app) {
        this.app = app;
    }

    protected App getApp() {
        return app;
    }

    protected String getExe() {
        String p = "app/onlineviewer/uniconvertor:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found uniconvertor config: {0}", p);
        }
        return exe;
    }

    public void convert(String src, String dest, String options) throws Exception {
        RunExe r = new RunExe(getApp().isDebug());
        List<String> cmd = new ArrayList<String>();

        cmd.add(getExe());

        if (!UtString.empty(options)) {
            String[] ar = options.split(" ");
            for (String s : ar) {
                cmd.add(s);
            }
        }

        cmd.add(src);
        cmd.add(dest);
        r.runexe(cmd, "", true, true);
    }

}
