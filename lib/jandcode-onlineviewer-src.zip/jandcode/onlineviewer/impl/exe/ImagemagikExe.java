package jandcode.onlineviewer.impl.exe;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.io.*;
import java.util.*;

/**
 * Конвертация различных картинок в jpg/png
 */
public class ImagemagikExe {

    private App app;

    public ImagemagikExe(App app) {
        this.app = app;
    }

    protected App getApp() {
        return app;
    }

    protected String getExe() {
        String p = "app/onlineviewer/imagemagick:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found imagemagick config: {0}", p);
        }
        return exe;
    }

    public void convert(String src, String dest, String options, boolean checkExistsAfterConvert) throws Exception {
        File destFile = new File(dest);
        destFile.delete();
        //

        RunExe r = new RunExe(getApp().isDebug());
        List<String> cmd = new ArrayList<String>();

        cmd.add(getExe());

        if (!UtString.empty(options)) {
            String[] ar = options.split(" ");
            for (String s : ar) {
                cmd.add(s);
            }
        }

        cmd.add(src);
        cmd.add(dest);
        r.runexe(cmd, "", false, false);

        //
        if (checkExistsAfterConvert) {
            if (!destFile.exists() || destFile.length() == 0) {
                if (destFile.exists()) {
                    destFile.delete();
                }

                throw new XError("Не удалось сконвертировать файл {0}", src);
            }
        }

    }

    public void rotate(String src, String dest, int degrees) throws Exception {
        convert(src, dest, "-rotate " + degrees, true);
    }

}
