package jandcode.onlineviewer.impl.exe;

import jandcode.app.*;
import jandcode.onlineviewer.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.io.*;
import java.util.*;

/**
 * pdf convertor
 */
public class PdfExe {

    private App app;
    private FileInfo f;
    private String localPdfFile;

    /**
     * @param app          контекст приложения
     * @param f            FileInfo
     * @param localPdfFile имя pdf фала, который находится в каталоге FileInfo
     */
    public PdfExe(App app, FileInfo f, String localPdfFile) {
        this.app = app;
        this.f = f;
        this.localPdfFile = localPdfFile;
    }

    protected App getApp() {
        return app;
    }

    protected String getFileData() {
        return f.getFile(localPdfFile);
    }

    protected String getExe() {
        String p = "app/onlineviewer/ghostscript:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found ghostscript config: {0}", p);
        }
        return exe;
    }

    public int getCountPages() throws Exception {
        int cp = f.getProps().getValueInt("countPages", -1);
        if (cp < 0) {
            // еще не считали
            RunExe r = new RunExe(getApp().isDebug());
            List<String> cmd = new ArrayList<String>();
            cmd.add(getExe());
            cmd.add("-q");
            cmd.add("-dNODISPLAY");
            cmd.add("-c");
            cmd.add(String.format("(%s) (r) file runpdfbegin pdfpagecount = quit", getFileData().replace('\\', '/')));
            List<String> res = r.runexe(cmd, "", true, true);

            // могут быть warning, ищем число
            for (String s : res) {
                String s1 = s.trim();
                if (UtString.empty(s1)) {
                    continue;
                }
                if (UtString.isNumChar(s1.charAt(0))) {
                    cp = UtCnv.toInt(s1);
                    f.getProps().setValue("countPages", cp);
                    f.save();
                    break;
                }
            }

        }
        return cp;
    }

    public File getPageFile(int numPage) throws Exception {
        int cp = getCountPages();
        if (numPage <= 0 || numPage > cp) {
            throw new XError("Invalid pagenum");
        }
        File pf = new File(f.getFile("page-" + numPage + ".png"));
        if (!pf.exists()) {
            // делаем страницу
            File tmpFile = new File(f.getFile("page.tmp"));

            RunExe r = new RunExe(getApp().isDebug());
            List<String> cmd = new ArrayList<String>();
            cmd.add(getExe());
            cmd.add("-dSAFER");
            cmd.add("-dBATCH");
            cmd.add("-dNOPAUSE");
            cmd.add("-sDEVICE=png16m");
            cmd.add("-r150");
            cmd.add("-sOutputFile=" + tmpFile.getAbsolutePath());
            cmd.add("-dFirstPage=" + numPage);
            cmd.add("-dLastPage=" + numPage);
            cmd.add(getFileData());
            r.runexe(cmd, "", false, true);

            if (!tmpFile.renameTo(pf)) {
                throw new XError("Error rename {0} to {1}", tmpFile.getAbsolutePath(), pf.getAbsolutePath());
            }

        }
        return pf;
    }

}
