package jandcode.onlineviewer.impl.exe;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Конвертация с использованием nconvert
 */
public class NConvertExe {

    private App app;

    public NConvertExe(App app) {
        this.app = app;
    }

    protected App getApp() {
        return app;
    }

    protected String getExe() {
        String p = "app/onlineviewer/nconvert:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found nconvert config: {0}", p);
        }
        return exe;
    }

    public void convertCgm(String src, String dest) throws Exception {
        RunExe r = new RunExe(getApp().isDebug());
        List<String> cmd = new ArrayList<String>();

        cmd.add(getExe());

        cmd.add("-overwrite");
        cmd.add("-o");
        cmd.add(dest);
        cmd.add("-out");
        cmd.add(UtFile.ext(dest));
        cmd.add("-in");
        cmd.add("cgm");
        cmd.add(src);

        r.runexe(cmd, "", false, true);
    }

}
