package jandcode.onlineviewer.impl.exe;

import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.logging.*;

import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Утилиты для запуска внешних exe
 */
public class RunExe {

    protected static Log log = LogFactory.getLog(RunExe.class);

    private boolean debugMode;

    public RunExe() {
    }

    public RunExe(boolean debugMode) {
        this.debugMode = debugMode;
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }

    /**
     * Запуск внешнего exe
     *
     * @param cmd     командная строка
     * @param dir     в каком каталоге запускать. Пусто - в текущем.
     * @param saveout сохранять ли вывод программы
     * @param err     true - если код возврата не 0, генерить exception
     * @return спсиок строк с выводом программы или пустой список, если saveout=false
     */
    public List<String> runexe(List<String> cmd, String dir, boolean saveout, boolean err) throws Exception {
        if (UtString.empty(dir)) {
            dir = UtFile.getWorkdir().getAbsolutePath();
        }

        if (log.isInfoEnabled()) {
            log.info("runexe: " + UtString.join(cmd, " "));
        }

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.directory(new File(dir));

        List<String> result = new ArrayList<String>();

        Process pr = pb.start();
        BufferedReader inr = new BufferedReader(new InputStreamReader(pr.getInputStream()));
        String line = inr.readLine();
        while (line != null) {
            if (saveout) {
                result.add(line);
            }
            line = inr.readLine();
        }
        pr.waitFor();
        int rescode = pr.exitValue();
        if (err) {
            if (rescode > 0) {
                if (log.isErrorEnabled()) {
                    log.error(MessageFormat.format("Ошибка при выполнении [{0}]: {1}. OUT ===\n{2}\n===", cmd, rescode, UtString.join(result, "\n")));
                }
                if (!debugMode) {
                    throw new XError("Ошибка при выполнении [{0}]: {1}", cmd, rescode);
                } else {
                    throw new XError("Ошибка при выполнении [{0}]: {1}. OUT ===\n{2}\n===", cmd, rescode, UtString.join(result, "\n"));
                }
            }
        }

        return result;
    }


}
