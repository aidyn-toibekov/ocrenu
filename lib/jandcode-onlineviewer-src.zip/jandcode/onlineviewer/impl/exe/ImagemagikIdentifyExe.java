package jandcode.onlineviewer.impl.exe;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;
import java.util.regex.*;

/**
 * identify.exe из состава ImageMagick
 */
public class ImagemagikIdentifyExe {

    private App app;

    public ImagemagikIdentifyExe(App app) {
        this.app = app;
    }

    protected App getApp() {
        return app;
    }

    protected String getExe() {
        String p = "app/onlineviewer/imagemagick:exe";
        String exe = getApp().getRt().getValueString(p);
        if (UtString.empty(exe)) {
            throw new XError("Not found imagemagick config: {0}", p);
        }
        return UtFile.join(UtFile.path(exe), "identify.exe");
    }

    /**
     * Сколько страниц в tiff-файле
     */
    public int tiffPages(String src) throws Exception {
        RunExe r = new RunExe(getApp().isDebug());
        List<String> cmd = new ArrayList<String>();

        cmd.add(getExe());

        cmd.add(src);
        cmd.add("-format");
        cmd.add("{{%p}}");
        cmd.add(src);

        List<String> res = r.runexe(cmd, "", true, false);

        String s = UtString.join(res, "\n");

        Pattern p = Pattern.compile("\\{\\{(\\d+)\\}\\}", Pattern.DOTALL);
        Matcher m = p.matcher(s);

        int cnt = 1;
        while (m.find()) {
            int a = UtCnv.toInt(m.group(1)) + 1;
            cnt = Math.max(cnt, a);
        }

        return cnt;
    }

}
