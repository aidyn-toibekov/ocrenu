package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;

import java.io.*;

/**
 * Конвертация различных картинок в jpg/png
 */
public class Image_imagemagick extends ImageFileConvertor {

    protected String format = "jpg";
    protected String options = "";

    /**
     * В какой формат конвертировать (png, jpg)
     */
    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    /**
     * Дополнительные опции для ImageMagick
     */
    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    protected String getFileConverted(FileInfo f) {
        return f.getFile("file." + getFormat());
    }

    public int getCountPages(FileInfo f) throws Exception {
        return 1;
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        File pf = new File(getFileConverted(f));
        if (!pf.exists()) {
            ImagemagikExe cnv = new ImagemagikExe(getApp());
            cnv.convert(f.getFileData(), pf.getAbsolutePath(), options, true);
        }
        return pf;
    }

}
