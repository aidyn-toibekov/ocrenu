package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.utils.*;
import jandcode.web.*;
import org.apache.commons.vfs2.*;

import java.io.*;

/**
 * Для файлов, которые находятся в виртуаьном каталоге web-приложения
 */
public class VdirFileProvider extends FileProvider {

    public void resolveFile(String path, File destFile, FileProviderFileInfo destFileInfo) throws Exception {
        //
        ResourceService rs = getApp().service(WebService.class).getResourceService();
        String f = rs.getFile(path);
        FileObject fo = UtFile.getFileObject(f);

        // расширение файла
        destFileInfo.setType(UtFile.ext(f));
        destFileInfo.setLastModInfo("" + fo.getContent().getLastModifiedTime());

        // копия файла
        OutputStream dstSt = new FileOutputStream(destFile);
        InputStream srcSt = fo.getContent().getInputStream();
        try {
            UtFile.copyStream(srcSt, destFile);
        } finally {
            srcSt.close();
            dstSt.close();
        }
    }

    public boolean checkModifiedFile(String path, String lastModInfo) throws Exception {
        //
        ResourceService rs = getApp().service(WebService.class).getResourceService();
        String f = rs.getFile(path);
        FileObject fo = UtFile.getFileObject(f);

        long t1 = UtCnv.toLong(lastModInfo);

        if (fo.getContent().getLastModifiedTime() > t1) {
            return true; // изменился
        } else {
            return false;
        }

    }
}
