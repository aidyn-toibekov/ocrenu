package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.onlineviewer.impl.exe.*;

import java.io.*;

/**
 * pdf
 */
public class Image_pdf extends ImageFileConvertor {

    public int getCountPages(FileInfo f) throws Exception {
        PdfExe cnv = new PdfExe(getApp(), f, OnlineviewerService.FILE_DATA);
        return cnv.getCountPages();
    }

    public File getPageFile(FileInfo f, int numPage) throws Exception {
        PdfExe cnv = new PdfExe(getApp(), f, OnlineviewerService.FILE_DATA);
        return cnv.getPageFile(numPage);
    }

}
