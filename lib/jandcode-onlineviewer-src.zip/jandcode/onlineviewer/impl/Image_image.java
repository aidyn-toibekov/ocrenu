package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;

import java.io.*;

/**
 * Картинка jpg,png,gif
 */
public class Image_image extends ImageFileConvertor {

    public int getCountPages(FileInfo f) {
        return 1;
    }

    public File getPageFile(FileInfo f, int numPage) {
        return new File(f.getFileData());
    }
}
