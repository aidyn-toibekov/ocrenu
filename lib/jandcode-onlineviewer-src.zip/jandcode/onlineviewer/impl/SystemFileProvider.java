package jandcode.onlineviewer.impl;

import jandcode.onlineviewer.*;
import jandcode.utils.*;

import java.io.*;

public class SystemFileProvider extends FileProvider {

    public void resolveFile(String path, File destFile, FileProviderFileInfo destFileInfo) throws Exception {
        // расширение файла
        destFileInfo.setType(UtFile.ext(path));
        File f = new File(path);
        destFileInfo.setLastModInfo("" + f.lastModified());
        //
        OutputStream dstSt = new FileOutputStream(destFile);
        InputStream srcSt = new FileInputStream(path);
        try {
            UtFile.copyStream(srcSt, destFile);
        } finally {
            srcSt.close();
            dstSt.close();
        }
    }

    public boolean checkModifiedFile(String path, String lastModInfo) throws Exception {
        File f = new File(path);
        long t1 = UtCnv.toLong(lastModInfo);
        if (f.lastModified() > t1) {
            return true; // изменился
        } else {
            return false;
        }
    }

}
