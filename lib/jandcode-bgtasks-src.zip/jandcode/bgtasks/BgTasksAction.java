package jandcode.bgtasks;

import jandcode.utils.error.*;
import jandcode.web.*;

import java.util.*;


/**
 * action для фоновых задач
 */
public class BgTasksAction extends WebAction {

    public static final String P_TASKID = "taskId";
    public static final String P_TASKIDS = "taskIds";
    public static final String P_TASKS = "tasks";


    /**
     * Безусловно остановить задачу.
     */
    public void stop(JsonActionWrapper wrap) throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        String id = getParams().getValueString(P_TASKID);
        Task task = svc.getTask(id);
        svc.removeTask(task);

        // success = true...
        Map res = new LinkedHashMap();
        wrap.setJson(res);
    }

    /**
     * Статус задач.
     * На входе: taskIds:[id1,id2]
     * На выходе: tasks: {id1:status,id2:status}
     */
    public void status(JsonActionWrapper wrap) throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        List<String> taskIds = (List<String>) UtJson.toObject(getParams().getValueString(P_TASKIDS));
        Map resStat = new HashMap();

        if (taskIds != null) {
            for (String id : taskIds) {
                int stat = -1;
                Task task = svc.findTask(id);
                if (task != null) {
                    stat = task.getStatus();
                }
                resStat.put(id, stat);
            }
        }
        //
        Map res = new LinkedHashMap();
        res.put(P_TASKS, resStat);
        wrap.setJson(res);
    }

    /**
     * Получить результат выполнения action.
     */
    public void result() throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        String id = getParams().getValueString(P_TASKID);
        Task t = svc.getTask(id);
        if (!t.isCompleted()) {
            throw new XError("Task not completed");
        }
        if (t.getException() != null) {
            svc.removeTask(t);
            throw t.getException();
        }
        if (t instanceof TaskAction) {
            ((TaskAction) t).renderActionResult(getRequest());
            svc.removeTask(t);
        } else {
            throw new XError("Not action task");
        }
    }

}
