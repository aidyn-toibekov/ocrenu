package jandcode.bgtasks;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.impl.*;
import org.apache.commons.logging.*;

/**
 * Этот класс получает уведомление при возниконовении ошибок при выполнении фоновых
 * задач. Регистрируется в сервисе.
 */
public class BgTasksErrorHandler extends CompRt {

    protected static Log log = LogFactory.getLog(BgTasksErrorHandler.class);

    public void handleError(Exception e) {
        String msg = new ErrorFormatterDefault(true, true,
                true).getMessage(UtError.createErrorInfo(e));
        log.error(msg);
    }

}
