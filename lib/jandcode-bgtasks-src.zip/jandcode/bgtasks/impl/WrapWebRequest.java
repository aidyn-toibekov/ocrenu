package jandcode.bgtasks.impl;

import jandcode.utils.error.*;
import jandcode.web.*;

import java.lang.reflect.*;
import java.util.*;

public class WrapWebRequest extends WebRequest {

    protected WebRequest wrap;

    static Field outStartedField;

    static {
        try {
            outStartedField = WebRequest.class.getDeclaredField("outStarted");
            outStartedField.setAccessible(true);
        } catch (Exception e) {
        }
    }

    public WrapWebRequest(WebRequest wrap) {
        super(wrap.getHttpServlet(),
                wrap.getHttpRequest(),
                new WrapHttpServletResponse(),
                wrap.getWebService()
        );
        this.wrap = wrap;
        this.httpRequest = new WrapHttpServletRequest(wrap.getHttpRequest());
    }

    //////

    public void redirect(String url, boolean virtualRoot, Map params) {
        throw new XError("unsupported");
    }

    public void redirect(String url, Map params) {
        throw new XError("unsupported");
    }

    public void redirect(String url) {
        throw new XError("unsupported");
    }

    //////

    public void moveDataToRealRequest(WebRequest r) throws Exception {
        r.sendError(errorCode, errorMessage);
        r.setException(exception);
        r.setContentType(contentType);
        r.render(renderObject, renderType);
        outStartedField.set(r, outStarted);
    }

}
