package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;
import jandcode.utils.*;
import jandcode.web.*;

import java.util.*;

/**
 * Фильтр перехватывает action и перенаправляет ее в фоновые процессы, если имеется
 * правильный заголовок.
 */
public class BgTasksWebFilter extends WebFilter {

    protected void onBeforeExec() throws Exception {
        if (!(getRequest() instanceof WrapWebRequest)) {
            String s = getRequest().getHttpRequest().getHeader("Jandcode-BgTasks-Start");
            if ("1".equals(s)) {
                // запрос на старт задачи
                BgTasksService svc = getApp().service(BgTasksService.class);
                TaskAction task = new TaskAction(getRequest());
                svc.addTask(task);

                //
                Map json = new LinkedHashMap();
                json.put("taskId", task.getId());

                getRequest().render("jc/json", UtCnv.toMap(
                        "data", json
                ));

                WebAction da = getApp().service(WebService.class).getObjectFactory().create(BgTaskDummyAction.class);
                getRequest().setAction(da);
            }
        }
    }
}
