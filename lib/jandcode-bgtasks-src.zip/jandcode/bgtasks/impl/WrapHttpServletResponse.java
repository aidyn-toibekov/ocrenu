package jandcode.bgtasks.impl;

import jandcode.utils.error.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Обертка ответа для сбора инфформации
 */
public class WrapHttpServletResponse implements HttpServletResponse {

    protected PrintWriter _writer;
    protected StringWriter _stringWriter;
    protected WrapServletOutputStream _stream;
    protected String _characterEncoding;
    protected int _contentLength = -1;
    protected String _contentType;
    protected HashMap<String, String> _headers = new HashMap<String, String>();
    protected int _status = -1;
    protected String _statusText;

    public WrapHttpServletResponse() {
    }

    public void addCookie(Cookie cookie) {
        throw new XError("unsupported");
    }

    public void sendError(int i) throws IOException {
        throw new XError("unsupported");
    }

    public void sendError(int i, String s) throws IOException {
        throw new XError("unsupported");
    }

    public void addIntHeader(String s, int i) {
        throw new XError("unsupported");
    }

    public void addDateHeader(String s, long l) {
        throw new XError("unsupported");
    }

    public String encodeRedirectUrl(String s) {
        throw new XError("unsupported");
    }

    public void addHeader(String s, String s1) {
        throw new XError("unsupported");
    }

    public Locale getLocale() {
        throw new XError("unsupported");
    }

    public ServletOutputStream getOutputStream() throws IOException {
        if (_stream == null) {
            _stream = new WrapServletOutputStream();
        }
        return _stream;
    }

    public int getBufferSize() {
        throw new XError("unsupported");
    }

    public void setDateHeader(String s, long l) {
        throw new XError("unsupported");
    }

    public void resetBuffer() {
        throw new XError("unsupported");
    }

    public void setContentType(String s) {
        _contentType = s;
    }

    public void setBufferSize(int i) {
        throw new XError("unsupported");
    }

    public void flushBuffer() throws IOException {
        throw new XError("unsupported");
    }

    public void reset() {
        throw new XError("unsupported");
    }

    public boolean containsHeader(String s) {
        throw new XError("unsupported");
    }

    public void setContentLength(int i) {
        _contentLength = i;
    }

    public String encodeUrl(String s) {
        throw new XError("unsupported");
    }

    public void setIntHeader(String s, int i) {
        throw new XError("unsupported");
    }

    public void setCharacterEncoding(String s) {
        _characterEncoding = s;
    }


    public PrintWriter getWriter() throws IOException {
        if (_writer == null) {
            _stringWriter = new StringWriter();
            _writer = new PrintWriter(_stringWriter);
        }
        return _writer;
    }

    public void setStatus(int i) {
        _status = i;
    }

    public String getContentType() {
        throw new XError("unsupported");
    }

    public String encodeRedirectURL(String s) {
        throw new XError("unsupported");
    }

    public void sendRedirect(String s) throws IOException {
        throw new XError("unsupported");
    }

    public String getCharacterEncoding() {
        throw new XError("unsupported");
    }

    public void setHeader(String s, String s1) {
        _headers.put(s, s1);
    }

    public boolean isCommitted() {
        throw new XError("unsupported");
    }

    public void setStatus(int i, String s) {
        _status = i;
        _statusText = s;
    }

    public String encodeURL(String s) {
        throw new XError("unsupported");
    }

    public void setLocale(Locale locale) {
        throw new XError("unsupported");
    }

    //////

    public void moveDataToRealResponse(HttpServletResponse r) throws Exception {
        if (_characterEncoding != null) {
            r.setCharacterEncoding(_characterEncoding);
        }
        if (_contentLength != -1) {
            r.setContentLength(_contentLength);
        }
        if (_contentType != null) {
            r.setContentType(_contentType);
        }
        for (String key : _headers.keySet()) {
            r.setHeader(key, _headers.get(key));
        }
        if (_status != -1 && _statusText != null) {
            r.setStatus(_status, _statusText);
        } else if (_status != -1) {
            r.setStatus(_status);
        }
        if (_stringWriter != null) {
            r.getWriter().write(_stringWriter.toString());
        } else if (_stream != null) {
            r.getOutputStream().write(_stream.getBytes());
        }
    }
}
