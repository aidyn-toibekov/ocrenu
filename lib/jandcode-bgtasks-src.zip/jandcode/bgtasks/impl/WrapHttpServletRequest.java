package jandcode.bgtasks.impl;

import jandcode.utils.*;
import jandcode.utils.error.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.security.*;
import java.util.*;

/**
 * Копия запроса. Не полная. Только для поддержки bgtasks.
 */
public class WrapHttpServletRequest implements HttpServletRequest {

    private String _authType;
    private Cookie[] _cookes;
    private ListNamed<HeaderItem> _headers = new ListNamed<HeaderItem>();
    private String _method;
    private String _pathInfo;
    private String _pathTranslated;
    private String _contextPath;
    private String _queryString;
    private String _remoteUser;
    private String _requestedSessionId;
    private String _requestURI;
    private StringBuffer _requestURL;
    private String _servletPath;
    private HttpSession _session;
    private int _contentLength;
    private String _contentType;
    private String _protocol;
    private String _scheme;
    private String _serverName;
    private int _serverPort;
    private String _remoteAddr;
    private String _remoteHost;
    private boolean _secure;
    private int _remotePort;
    private String _localName;
    private String _localAddr;
    private int _localPort;
    private HashMap<String, Object> _attributes = new HashMap<String, Object>();

    class HeaderItem extends Named {
        String value;

        public HeaderItem(String name, String value) {
            this.name = name;
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public WrapHttpServletRequest(HttpServletRequest orig) {
        _authType = orig.getAuthType();
        _method = orig.getMethod();
        _pathInfo = orig.getPathInfo();
        _pathTranslated = orig.getPathTranslated();
        _contextPath = orig.getContextPath();
        _queryString = orig.getQueryString();
        _remoteUser = orig.getRemoteUser();
        _requestedSessionId = orig.getRequestedSessionId();
        _requestURI = orig.getRequestURI();
        _requestURL = new StringBuffer();
        _requestURL.append(orig.getRequestURL());
        _servletPath = orig.getServletPath();
        _session = orig.getSession();
        _contentLength = orig.getContentLength();
        _contentType = orig.getContentType();
        _protocol = orig.getProtocol();
        _scheme = orig.getScheme();
        _serverName = orig.getServerName();
        _serverPort = orig.getServerPort();
        _remoteAddr = orig.getRemoteAddr();
        _remoteHost = orig.getRemoteHost();
        _secure = orig.isSecure();
        _remotePort = orig.getRemotePort();
        _localName = orig.getLocalName();
        _localAddr = orig.getLocalAddr();
        _localPort = orig.getLocalPort();

        //
        Cookie[] cc = orig.getCookies();
        if (cc != null) {
            _cookes = new Cookie[cc.length];
            for (int i = 0; i < cc.length; i++) {
                _cookes[i] = cc[i];
            }
        }
        //
        Enumeration en = orig.getHeaderNames();
        while (en.hasMoreElements()) {
            String pn = en.nextElement().toString();
            _headers.add(new HeaderItem(pn, orig.getHeader(pn)));
        }

    }

    public String getAuthType() {
        return _authType;
    }

    public Cookie[] getCookies() {
        return _cookes;
    }

    //////

    public long getDateHeader(String s) {
        throw new XError("unsupported");
    }

    public String getHeader(String s) {
        HeaderItem it = _headers.find(s);
        if (it == null) {
            return null;
        }
        return it.getValue();
    }

    public Enumeration getHeaders(String s) {
        List<String> a = new ArrayList<String>();
        HeaderItem it = _headers.find(s);
        if (it != null) {
            a.add(it.getValue());
        }
        return Collections.enumeration(a);
    }

    public Enumeration getHeaderNames() {
        List<String> a = new ArrayList<String>();
        for (HeaderItem it : _headers) {
            a.add(it.getName());
        }
        return Collections.enumeration(a);
    }

    public int getIntHeader(String s) {
        String s1 = getHeader(s);
        if (s1 == null) {
            return -1;
        }
        return Integer.parseInt(s1);
    }

    //////

    public String getMethod() {
        return _method;
    }

    public String getPathInfo() {
        return _pathInfo;
    }

    public String getPathTranslated() {
        return _pathTranslated;
    }

    public String getContextPath() {
        return _contextPath;
    }

    public String getQueryString() {
        return _queryString;
    }

    public String getRemoteUser() {
        return _remoteUser;
    }

    public boolean isUserInRole(String s) {
        throw new XError("unsupported");
    }

    public Principal getUserPrincipal() {
        throw new XError("unsupported");
    }

    public String getRequestedSessionId() {
        return _requestedSessionId;
    }

    public String getRequestURI() {
        return _requestURI;
    }

    public StringBuffer getRequestURL() {
        return _requestURL;
    }

    public String getServletPath() {
        return _servletPath;
    }

    public HttpSession getSession(boolean b) {
        throw new XError("unsupported");
    }

    public HttpSession getSession() {
        return _session;
    }

    public boolean isRequestedSessionIdValid() {
        throw new XError("unsupported");
    }

    public boolean isRequestedSessionIdFromCookie() {
        throw new XError("unsupported");
    }

    public boolean isRequestedSessionIdFromURL() {
        throw new XError("unsupported");
    }

    public boolean isRequestedSessionIdFromUrl() {
        throw new XError("unsupported");
    }

    public Object getAttribute(String s) {
        return _attributes.get(s);
    }

    public Enumeration getAttributeNames() {
        return Collections.enumeration(_attributes.keySet());
    }

    public String getCharacterEncoding() {
        return "UTF-8";
    }

    public void setCharacterEncoding(String s) throws UnsupportedEncodingException {
        //
    }

    public int getContentLength() {
        return _contentLength;
    }

    public String getContentType() {
        return _contentType;
    }

    public ServletInputStream getInputStream() throws IOException {
        throw new XError("unsupported");
    }

    public String getParameter(String s) {
        throw new XError("unsupported");
    }

    public Enumeration getParameterNames() {
        throw new XError("unsupported");
    }

    public String[] getParameterValues(String s) {
        throw new XError("unsupported");
    }

    public Map getParameterMap() {
        throw new XError("unsupported");
    }

    public String getProtocol() {
        return _protocol;
    }

    public String getScheme() {
        return _scheme;
    }

    public String getServerName() {
        return _serverName;
    }

    public int getServerPort() {
        return _serverPort;
    }

    public BufferedReader getReader() throws IOException {
        throw new XError("unsupported");
    }

    public String getRemoteAddr() {
        return _remoteAddr;
    }

    public String getRemoteHost() {
        return _remoteHost;
    }

    public void setAttribute(String s, Object o) {
        _attributes.put(s, o);
    }

    public void removeAttribute(String s) {
        _attributes.remove(s);
    }

    public Locale getLocale() {
        throw new XError("unsupported");
    }

    public Enumeration getLocales() {
        throw new XError("unsupported");
    }

    public boolean isSecure() {
        return _secure;
    }

    public RequestDispatcher getRequestDispatcher(String s) {
        throw new XError("unsupported");
    }

    public String getRealPath(String s) {
        throw new XError("unsupported");
    }

    public int getRemotePort() {
        return _remotePort;
    }

    public String getLocalName() {
        return _localName;
    }

    public String getLocalAddr() {
        return _localAddr;
    }

    public int getLocalPort() {
        return _localPort;
    }
}
