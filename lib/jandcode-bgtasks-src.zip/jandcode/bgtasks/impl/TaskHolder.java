package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * Хранилище задач
 */
public class TaskHolder {

    // все задачи по id
    private Map<String, Task> itemsById = new ConcurrentHashMap<String, Task>();

    // все задачи
    private List<Task> items = new ArrayList<Task>();

    /**
     * Генерация id для новой задачи
     */
    protected String generateId() {
        return UUID.randomUUID().toString();
    }

    //////

    /**
     * Добавить
     */
    public void add(Task task) {
        task.setId(generateId());
        task.setStatus(Task.STATUS_QUE);
        synchronized (this) {
            items.add(task);
            itemsById.put(task.getId(), task);
        }
    }

    /**
     * Удалить
     */
    public void remove(Task task) {
        synchronized (this) {
            items.remove(task);
            itemsById.remove(task.getId());
        }
    }

    /**
     * Переместить задачу в список выполненных.
     */
    public void moveToCompleted(Task task) {
        synchronized (this) {
            // ставим статус
            task.setStatus(Task.STATUS_COMPLETED);
            // переносим в конец очереди
            items.remove(task);
            items.add(task);
        }
    }

    /**
     * Переместить задачу в список запущенных
     */
    public void moveToRunned(Task task) {
        synchronized (this) {
            task.setStatus(Task.STATUS_RUNNED);
        }
    }

    //////

    /**
     * Найти по id
     */
    public Task find(String id) {
        return itemsById.get(id);
    }

    /**
     * Заполняет переданные списки:
     *
     * @param que       очередь для выполнения
     * @param runned    выполняющиеся задачи
     * @param completed выполненные задачи
     */
    public void grabQue(List<Task> que, List<Task> runned, List<Task> completed) {
        synchronized (this) {
            List<Task> forRemove = null;
            for (Task t : items) {
                if (t.isQue()) {
                    if (t.isEnabled()) {
                        que.add(t);
                    } else {
                        // удалить нужно такую
                        if (forRemove == null) {
                            forRemove = new ArrayList<Task>();
                        }
                        forRemove.add(t);
                    }
                }
                if (t.isRunned()) {
                    runned.add(t);
                }
                if (t.isCompleted()) {
                    completed.add(t);
                }
            }
            if (forRemove != null) {
                for (Task t : forRemove) {
                    remove(t);
                }
            }
        }
    }

    /**
     * Пуста ли очередь: не должно быть задач в очереди и выполняющися задач
     */
    public boolean isQueEmpty() {
        synchronized (this) {
            for (Task t : items) {
                if (t.isQue()) {
                    return false;
                }
                if (t.isRunned()) {
                    return false;
                }
            }
        }
        return true;
    }

}
