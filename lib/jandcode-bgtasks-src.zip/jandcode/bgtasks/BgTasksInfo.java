package jandcode.bgtasks;

import java.util.*;

/**
 * Контейнер для информации о текущем состоянии очереди
 */
public class BgTasksInfo {

    private List<Task> que = new ArrayList<Task>();
    private List<Task> runned = new ArrayList<Task>();
    private List<Task> completed = new ArrayList<Task>();

    /**
     * Задачи в очереди
     */
    public List<Task> getQue() {
        return que;
    }

    /**
     * Запущенные задачи
     */
    public List<Task> getRunned() {
        return runned;
    }

    /**
     * Выполненные задачи
     */
    public List<Task> getCompleted() {
        return completed;
    }

}
