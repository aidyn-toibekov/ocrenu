package jandcode.bgtasks;

import jandcode.app.*;

import java.util.*;

/**
 * Сервис фоновых задач
 */
public abstract class BgTasksService extends CompRt implements IAppStartup, IAppShutdown {

    /**
     * Добавить задачу.
     */
    public abstract void addTask(Task task);

    /**
     * Возвращает задачу по id
     *
     * @return null, если не найдена
     */
    public abstract Task findTask(String id);

    /**
     * Возвращает задачу по id
     *
     * @return ошибка, если не найдена
     */
    public abstract Task getTask(String id);

    /**
     * Удалить задачу. Если она запущена, то поток останавливается.
     */
    public abstract void removeTask(Task task);

    //////

    /**
     * Выбиральщики задач
     */
    public abstract Collection<BgTasksChoicer> getChoicers();

    /**
     * Число потоков для выполнения задач
     */
    public abstract int getMaxThreads();

    public abstract void setMaxThreads(int maxThread);

    /**
     * true - входящая очередь задач пустая, никаких задач не выполняется
     */
    public abstract boolean isQueEmpty();

    /**
     * Информация о текущем состоянии очереди
     */
    public abstract BgTasksInfo getTasksInfo();

    ////// errorhandler

    /**
     * Обработчик ошибок
     */
    public abstract BgTasksErrorHandler getErrorHandler();

    ////// timer

    /**
     * false - сервис запрещен
     */
    public abstract void setEnabled(boolean enabled);

    public abstract boolean isEnabled();

    /**
     * Задержка перед первым выполнением
     */
    public abstract void setDelay(long delay);

    public abstract long getDelay();

    /**
     * Периодичность выполнения
     */
    public abstract void setPeriod(long period);

    public abstract long getPeriod();

}
